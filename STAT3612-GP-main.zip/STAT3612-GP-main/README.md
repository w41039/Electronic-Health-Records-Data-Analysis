# STAT3612_Group16_Superpass_GP 🏆

### 📌 Group Members:
      CHAN Yuk Wai 
      DING Zhui 
      WANG Xi Zhuo
      YU Xin Yao 
      YUNG Yiu Yin
      
### 📋Progress:

**Project Proposal** on Oct 30: [proposal](https://github.com/WangXizhuo/STAT3612-GP/blob/main/STAT3612_Proposal.pdf)


**Final presentation slides** on Nov 28: [Presentation Slides](https://github.com/WangXizhuo/STAT3612-GP/blob/main/STAT3612%20GP_superpass.pptx)

**Final report**: on Dec 7 
